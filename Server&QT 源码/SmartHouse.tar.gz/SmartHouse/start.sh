#!/bin/sh
cd /usr/local/QtEmbedded-4.5.2/401
./IntelliHouse -qws &

