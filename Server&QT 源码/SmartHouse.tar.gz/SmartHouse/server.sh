#!/bin/sh
/usr/local/SmartHouse/401/server_arm &
