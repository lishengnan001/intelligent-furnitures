export QTDIR=/usr/local/Trolltech/QtEmbedded-4.7.3-arm
export QPEDIR=/usr/local/Trolltech/QtEmbedded-4.7.3-arm
export PATH=$QTDIR/bin:$PATH
export LD_LIBRARY_PATH=$QTDIR/lib:/usr/local/lib:$LD_LIBRARY_PATH
export TSLIB_TSDEVICE=/dev/input/event1
export TSLIB_CONFFILE=/usr/local/etc/ts.conf
export TSLIB_PLUGINDIR=/usr/local/lib/ts
export TSLIB_CALIBFILE=/etc/pointercal
export QWS_MOUSE_PROTO="TSLIB:/dev/input/event1 USB:/dev/input/mice"
export QWS_SIZE='800x480'
export QWS_KEYBOARD=TTY:/dev/tty1
source /etc/profile
if [ ! -f /etc/pointercal ]
then
	echo "Touch Screen has not been calibrate yet ..."
	/usr/sbin/ts_calibrate
	echo ""
	echo "Now reboot the system for saving the /etc/pointercal in flash"
	echo ""
	reboot
fi
/usr/local/QtEmbedded-4.5.2/401/IntelliHouse -qws &

